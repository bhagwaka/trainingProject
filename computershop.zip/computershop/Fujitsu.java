package project.computershop;

public interface Fujitsu {
	public int getFujitsuCount(int count);
	public int setFujitsuCount(int count);
	public void getFujitsuPrice();
}
