package project.computershop;

public interface Dell {
	public int getDellCount(int count);
	public int setDellCount(int count);
	public void getDellPrice();
}
