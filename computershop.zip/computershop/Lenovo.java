package project.computershop;

public interface Lenovo {
	public int getLenovoCount(int count);
	public int setLenovoCount(int count);
	public void getLenovoPrice();
}
