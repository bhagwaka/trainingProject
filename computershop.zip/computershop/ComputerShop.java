package project.computershop;

import java.util.Scanner;

class ComputerShop implements Lenovo,Dell,Fujitsu
{
	
	Scanner scan = new Scanner(System.in);
	static int lenovo_count=20;
	static int dell_count=20;
	static int fujitsu_count=20;
	static int FinalIncome = 0;

	public void grossIncome(int value)
	{
		 int gross_value = (value/100)*20;
		 FinalIncome = FinalIncome+gross_value;
	}
	
	public int setLenovoCount(int count){
		lenovo_count = lenovo_count + count;
		System.out.println(lenovo_count);
		return count;
	}
	
	public int setDellCount(int count){
		dell_count = dell_count+ count;
		System.out.println(dell_count);
		return count;
	}
	
	public int setFujitsuCount(int count){
		fujitsu_count = fujitsu_count + count;
		System.out.println(fujitsu_count);
		return count;
	}
	
	public int getLenovoCount(int count){
		lenovo_count = lenovo_count - count;
		System.out.println("Remaining Lenovo Units "+lenovo_count);
		return count;
	}
	
	public void getLenovoPrice()
	{
		ComputerShop cs = new ComputerShop();
		System.out.println("Cost of Lenovo Laptop :- 40000rs");
		System.out.println("Enter The quantity");
		int count = scan.nextInt();
		cs.getLenovoCount(count);
		int price = 40000*count;
		System.out.println("Total Price "+price);
	}

	@Override
	public int getFujitsuCount(int count) {
		fujitsu_count = fujitsu_count- count;
		System.out.println("Remaining Fujitsu Units"+fujitsu_count);
		return count;
	}
	public void getFujitsuPrice()
	{
		ComputerShop cs = new ComputerShop();
		System.out.println("Cost of Fujitsu Laptop :- 20000rs");
		System.out.println("Enter The quantity");
		int count = scan.nextInt();
		cs.getFujitsuCount(count);
		int price = 20000*count;
		System.out.println("Total Price "+price);
	}

	@Override
	public int getDellCount(int count) {
		dell_count = dell_count - count;
		System.out.println("Remaining Dell Units"+dell_count);
		return count;		
	}
	
	public void getDellPrice()
	{
		ComputerShop cs = new ComputerShop();
		System.out.println("Cost of Dell Laptop :- 10000rs");
		System.out.println("Enter The quantity");
		int count = scan.nextInt();
		cs.getDellCount(count);
		int price = 10000*count;
		System.out.println("Total Price "+price);
	}
	
	
//Making Investment Method
	void makeInvestment()
	{
		int choice;
		ComputerShop cs = new ComputerShop();
		do{
		System.out.println("What Would you like to order from Wholesale?\n");
		System.out.println("1.Lenovo \n2.Dell \n3.Fujitsu \n4.Exit");
		choice = scan.nextInt();
		switch(choice)
		{
		case 1:
				System.out.println("Wholesale Cost of Lenovo is 30000");
				System.out.println("Enter The Quantity");
				int count1 = scan.nextInt();
				cs.setLenovoCount(count1);
				int total1 = 30000*count1;
				cs.grossIncome(total1);
				System.out.println("Total Cost is"+total1);
				break;
				
		case 2:System.out.println("Wholesale Cost of Dell is 20000");
				System.out.println("Enter The Quantity");
				int count2 = scan.nextInt();
				cs.setDellCount(count2);
				int total2 = 20000*count2;
				cs.grossIncome(total2);
				System.out.println("Total Cost is"+total2);
				
				break;
		
		case 3:System.out.println("Wholesale Cost of Fujitsu is 10000");
				System.out.println("Enter The Quantity");
				int count3 = scan.nextInt();
				cs.setFujitsuCount(count3);
				int total3 = 10000*count3;
				cs.grossIncome(total3);
				System.out.println("Total Cost is"+total3);
				break;
		case 4:break;
		}
		}while(choice!=4);
	}

	
//Purchase Method
	void purchase()
	{
		ComputerShop cs = new ComputerShop();
		int choice;
		do{
		System.out.println("What Would you like to Purchase?\n");
		System.out.println("1.Lenovo \n2.Dell \n3.Fujitsu \n4.Exit");
		choice = scan.nextInt();
		switch(choice)
		{
		case 1:cs.getLenovoPrice();
				break;
		case 2:cs.getDellPrice();
				break;
		case 3:cs.getFujitsuPrice();
				break;
		case 4:break;
		}
	}while(choice!=4);
}
		
	
//Main Method	
public static void main(String[] args) {
			ComputerShop cs = new ComputerShop();
			int choice;
			Scanner scan = new Scanner(System.in);
			do{
			System.out.println("**** Smart Computers ****");
			System.out.println("1.Purchase Item \t2.Make  Investment. \t3.GrossIncome \t4.Exit");
			choice = scan.nextInt();
			switch(choice)
			{
			case 1: cs.purchase();	
				break;
			case 2:cs.makeInvestment();
				break;
			case 3:System.out.println("Final Income is "+FinalIncome);
				break;
			case 4:
				break;
			}
		}while(choice!=0);
	}
}