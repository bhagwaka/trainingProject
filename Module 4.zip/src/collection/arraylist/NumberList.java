package collection.arraylist;
import java.lang.Number;
import java.util.ArrayList;
public class NumberList {
	
	static void printAll(){
		for(Double sl:numList)
		System.out.println(sl);
	}
static ArrayList<Double> numList = new ArrayList<>();
	public static void main(String[] args) {
		numList.add(1.5);
		numList.add(23.21);
		numList.add(123.56);
		numList.add(123456.12);
		numList.add(123456789.3);
		printAll();
	}
}
