package collection.arraylist;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class TreeSet1 {
	static TreeSet<String> names = new TreeSet<>();
public static void main(String[] args) {
	
	names.add("Chameli");
	names.add("Hateli");
	names.add("Patkeli");
	names.add("Tatkeli");
	names.add("Satkeli");
	
	System.out.println("Ascending Order");
	Iterator it1 = names.iterator();
	while(it1.hasNext())
	{
		String ts = (String)it1.next();
		System.out.println(ts);
	}
	
	System.out.println("Descending Order");
	Iterator it2 = names.descendingIterator();
	while(it2.hasNext())
	{
		String ts = (String)it2.next();
		System.out.println(ts);
	}
	
	System.out.println("Search record?Enter Name..");
	Scanner scan = new Scanner(System.in);
	String name = scan.next();
	find(name);
}
static boolean find(String name){
	boolean value = false;
	Iterator it3 = names.iterator();
	while(it3.hasNext())
	{
		String str = (String)it3.next();
		if(str.equals(name)){
			value = true;
			System.out.println("Record Found");
			break;
		}
		else{
		System.out.println("Record Not Found");	
		break;
		}
	}
	return value;
	}
}
