package collection.arraylist;

import java.util.ArrayList;

public class StringList {
	
	static void printAll(){
		for(String sl:strList)
		System.out.println(sl);
	}
static ArrayList<String> strList = new ArrayList<>();
	public static void main(String[] args) {
		strList.add("Avoid");
		strList.add("Any");
		strList.add("Contact");
		strList.add("With");
		strList.add("Strangers");
		printAll();
	}

}
