package exception.practice;

public class UserDefinedException extends Exception{
	public UserDefinedException(){
		//System.out.println("User defined exception thrown");
	}
	public String toString(){
		return  "Age cannot be greater than 60 and less than 18";
	}
}
