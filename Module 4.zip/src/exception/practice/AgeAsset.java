package exception.practice;

public class AgeAsset extends UserDefinedException{
	int age = 0;
	public void ageCheck(int a) {
		int age = a;
		if(age>18&&age<60)
		{
			System.out.println("Age of Voter is "+age+"is eligible for voting");
			
		}	
		else{
			try {
				throw new UserDefinedException();
			
			} catch (UserDefinedException e) {
				
				System.out.println(e);
			}
		}
}
	
}
