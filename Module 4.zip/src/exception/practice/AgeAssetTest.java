package exception.practice;

public class AgeAssetTest {
	public static void main(String[] args) {
		String name = args[0];
		int age = Integer.parseInt(args[1]);
		AgeAsset asg = new AgeAsset();
		System.out.println("the name of the voter is "+args[0]);
		asg.ageCheck(age);
		
	}
}
