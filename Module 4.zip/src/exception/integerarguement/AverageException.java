package exception.integerarguement;

public class AverageException {
	static int sum;
	static int average;
	static int marks[] = new int[5];
	public static void main(String[] args) throws ArrayIndexOutOfBoundsException {
		for(int i = 0; i < 5 ;i++)
		{
			marks[i] = Integer.parseInt(args[i]);
		}
		if(marks.length<5){
			throw new ArrayIndexOutOfBoundsException();
		}
		else{
			for(int i = 0; i<marks.length;i++)
			{
				sum = sum+marks[i];
			}
			average = sum/5;
			System.out.println("Average is"+average);
		}
	}
}
class ArrayIndexOutOfBoundsException extends Exception{
	public String toString(){
		return  "Enter 5 integers please";
	
}
}