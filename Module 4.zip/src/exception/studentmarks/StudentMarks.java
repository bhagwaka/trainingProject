package exception.studentmarks;

import java.text.NumberFormat;
import java.util.Scanner;

public class StudentMarks {
	Scanner scan = new Scanner(System.in);
	int sum = 00;
	float avg = 0.0f;

	void getInputNameAndMarks() throws Exception {

		{
			System.out.println(" Name and Enter Marks of 3 Subjects");
			try {
				String student_name = scan.next();
				String m1 = scan.next();

				String m2 = scan.next();
				String m3 = scan.next();

				int marks2 = Integer.parseInt(m2);
				int marks1 = Integer.parseInt(m1);
				int marks3 = Integer.parseInt(m3);
				if ((marks1 < 0) || (marks2 < 0) || (marks3 < 0)||(marks1 >100 ) || (marks2 >100) || (marks3 > 100)) {
					throw new WrongInputException();
					
				} else {
					sum = marks1 + marks2 + marks3;
					avg = sum / 3;
					System.out.println(student_name + ":Average is " + avg);
				}
			} catch (NumberFormatException e) {
				System.out.println("Enter Numbers of Integer Type only...Please Fill again");
				e.getMessage();
				new StudentMarks().getInputNameAndMarks();
			}
			finally{
				new StudentMarks().getInputNameAndMarks();
			}
		}
	}
}
