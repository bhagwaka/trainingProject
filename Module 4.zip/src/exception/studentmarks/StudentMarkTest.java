package exception.studentmarks;

public class StudentMarkTest {
	static int marks1,marks2,marks3;
	public static void main(String[] args) throws Exception {
		StudentMarks s1 = new StudentMarks();
		StudentMarks s2 = new StudentMarks();
		
		s1.getInputNameAndMarks();
		s2.getInputNameAndMarks();
	}
}
