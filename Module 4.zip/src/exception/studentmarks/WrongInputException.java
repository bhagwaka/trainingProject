package exception.studentmarks;

public class WrongInputException extends Exception{

	public WrongInputException() {
		System.out.println("Marks Should be between 0 and 100");
	}

}
