package fujitsu.animal;

public class AnimalTest {

	public static void main(String[] args) {
		
		Animal a = new Dog();
		System.out.println("Calling a dog");
		a.setName("Shiro");
		a.setColor("Black");
		a.setNature("Loyal");
		new Dog().sound();
		System.out.println(a);
		
		Animal h = new Horse();
		System.out.println("Calling a Horse");
		h.setName("Shiro");
		h.setColor("Black");
		h.setNature("Friendly");
		new Horse().sound();
		System.out.println(h);
		
		Animal c = new Cat();
		System.out.println("Calling a Cat");
		c.setName("Shiro");
		c.setColor("Black");
		c.setNature("Runner");
		new Cat().sound();
		System.out.println(c);
	}

}
