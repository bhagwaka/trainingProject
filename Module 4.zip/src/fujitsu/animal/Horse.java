package fujitsu.animal;

public class Horse extends Animal{
	public void sound(){
		System.out.println("whee-whee");
	}
}
