package fujitsu.animal;
public class Animal {
	protected String name;
	protected String color;
	protected String nature;
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getNature() {
		return nature;
	}
	public void setNature(String nature) {
		this.nature = nature;
	}
	@Override
	public String toString() {
		return "Animal [name=" + name + ", color=" + color + ", nature=" + nature + "]";
	}
}
