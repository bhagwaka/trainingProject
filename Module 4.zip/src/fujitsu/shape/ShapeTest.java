package fujitsu.shape;

import java.util.Scanner;

public class ShapeTest {
	
	static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		
		Circle c = new Circle();
		System.out.println("Enter Radius Value");
		float rad = scan.nextFloat();
		float areaOfCircle=c.calcArea(rad);
		System.out.println(areaOfCircle);
		
		Square s = new Square();
		System.out.println("Enter Side's to calculate area of square");
		float a = scan.nextFloat();
		float areaOfSquare=s.calcArea(a);
		System.out.println(areaOfSquare);
		
		Sphere sph = new Sphere();
		System.out.println("Enter Side's to calculate Volume of Sphere");
		 float srad = scan.nextFloat();
		float areaOfSphere=sph.calcVolume(srad);
		System.out.println(areaOfSphere);
		
		Cuboid cub = new Cuboid();
		System.out.println("Enter Side's to calculate Volume of Cuboid");
		float ca = scan.nextFloat();
		float areaOfCuboid=cub.calcVolume(ca);
		System.out.println(areaOfCuboid);
	}
	
}
