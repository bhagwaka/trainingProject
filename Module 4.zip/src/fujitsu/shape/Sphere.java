package fujitsu.shape;

public class Sphere implements CalVolume{
	public float calcVolume(float a) {
	float area1=var*a*a*a;
		
		return area1;
	}
}
