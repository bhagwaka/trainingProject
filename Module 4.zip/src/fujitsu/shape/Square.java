package fujitsu.shape;

public class Square implements CalArea {
	@Override
	public float calcArea(float a) {
		float area = a * a;
		return area;
	}

}
