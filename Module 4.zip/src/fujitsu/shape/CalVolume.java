package fujitsu.shape;

public interface CalVolume{
	public static float var = (1.33f*3.14f);
	public static float a=0.0f;
	float calcVolume(float a);
}
