package fujitsu.shape;

public class Circle implements CalArea {
	public float calcArea(float rad) {
		float area = pi * rad * rad;
		return area;
	}

}
