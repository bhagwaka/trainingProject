package student.controller;

public class StudentController {
	
}
