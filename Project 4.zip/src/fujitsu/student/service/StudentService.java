package fujitsu.student.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import fujitsu.student.model.Student;

public class StudentService {
	static ArrayList<Student> studentList = new ArrayList<>();

	public List<Student> findAll() {
		return studentList;
	}

	public static float calculate_Percentage(int m1, int m2, int m3) {
		int total = ((m1 + m2 + m3) * 100 / 300);
		return total;
	}

	public static String calculate_Grade(float percentage) {
		if (percentage < 100 && percentage >= 80) {
			return "A";
		} else if (percentage < 80 && percentage >= 60) {
			return "B";
		} else if (percentage < 60 && percentage >= 45) {
			return "C";
		} else {
			return "Fail";
		}
	}

	public void add(Student student) {
		studentList.add(student);
	}

	public void update(int id, String name) {
		for (Student s : studentList) {
			if (s.getStudent_id() == id) {
				s.setStudent_name(name);
				break;
			}
		}
	}

	public void delete(int id) {
		Iterator<Student> it = studentList.iterator();
		while (it.hasNext()) {
			Student s = (Student) it.next();
			if (s.getStudent_id() == id) {
				it.remove();
				break;
			}

			System.out.println("Record Deleted Successfully");
		}

	}

	public void findById(int id) {
		for (Student s : studentList) {
			if (s.getStudent_id() == id) {
				System.out.println("Found");
				break;
			}
		}
	}

	public void generateReport(int id) {
		 Iterator<Student> it = studentList.iterator();
		 while (it.hasNext()) {
				Student s = (Student) it.next();
				if (s.getStudent_id() == id) {
				System.out.println("...."+s.getStudent_name()+" Marksheet....");
				System.out.println("=================================");
				System.out.println("Name:- "+(s.getStudent_name()));
				System.out.println("Student ID:- "+(s.getStudent_id()));
				System.out.println("=================================");
				System.out.println("Maths:- "+(s.getMark1()));
				System.out.println("Maths:- "+(s.getMark2()));
				System.out.println("Maths:- "+(s.getMark3()));
				System.out.println("=================================");
				System.out.println("Percentage:- "+(s.getPercentage()));
				System.out.println("Grade:-"+(s.getGrade()));
				}
	}
	
	

	
}
}
