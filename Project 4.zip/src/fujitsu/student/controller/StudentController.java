package fujitsu.student.controller;

import fujitsu.student.exception.InvalidInputException;
//import fujitsu.student.model;
import fujitsu.student.model.Student;
import fujitsu.student.service.StudentService;

import java.util.List;
import java.util.Scanner;

public class StudentController {
	static Scanner scan = new Scanner(System.in);
	static StudentService service = new StudentService();

	static Student getStudentData() throws Exception {
		System.out.println("Enter Student ID, Name and Marks Of 3 Subjects");
		int mark1 = 0,mark2 = 0,mark3 = 0,student_id = 0;
		float percentage = 0;
		String grade = null;
		String student_name = null ;
		
		try{
	 student_id = scan.nextInt();
	
		student_name = scan.next();
		 mark1 = scan.nextInt();
		 mark2 = scan.nextInt();
		 mark3 = scan.nextInt();
		 percentage = StudentService.calculate_Percentage(mark1, mark2, mark3);
		grade = StudentService.calculate_Grade(percentage);

		if ((mark1 < 0) || (mark2 < 0) || (mark3 < 0)||(mark1 >100 ) || (mark2 >100) || (mark3 > 100)) {
			throw new InvalidInputException();
		}
		else{
			System.out.println("Record Added!");
		}
	}catch(InvalidInputException e)
	{
		System.out.println("Enter Numbers of Integer Type only...Please Fill again");
		e.getMessage();
	}
	Student student = new Student(student_id, student_name, mark1, mark2, mark3, percentage, grade);
	return student;
}

	public static List<Student> findAll() {
		return service.findAll();
	}

	static void add(Student student) {
		
		service.add(student);
	}

	static void update(int id, String name) {
		service.update(id, name);

	}

	static void delete(int id) {
		service.delete(id);
	}

	static void findById(int id) {
		service.findById(id);
	}

	static void generateReport(int id) {
		service.generateReport(id);
	}

	public static void main(String args[]) {
		// System.out.println(findAll());
		// add(getStudentData());
		// System.out.println(findAll());
		// generateReport(1);
		int choice;
		do{
		System.out.println("Menu");
		System.out.println(
				"1.Add Student Data. \n2.Update Student Data\n3.Find Record By ID \n4.Show All Data \n5.Delete Record \n6.Generate Report Card");
		Scanner scan = new Scanner(System.in);
		choice = scan.nextInt();
		switch (choice) {
		case 1:
			try {
				getStudentData();
			} catch (Exception e) {
				e.getMessage();
				e.printStackTrace();
			}
			//System.out.println("Record Added Successfully");
			break;
		case 2:
			System.out.println("Enter ID and Name");
			Scanner scan1 = new Scanner(System.in);
			int id1 = scan1.nextInt();
			String name = scan1.next();
			update(id1, name);
			System.out.println("Record Updated Successfully");
			break;
		case 3:
			System.out.println("Enter ID");
			Scanner scan2 = new Scanner(System.in);
			int id2 = scan2.nextInt();
			findById(id2);
		case 4:
			findAll();
		case 5:
			System.out.println("Enter ID");
			Scanner scan3 = new Scanner(System.in);
			int id3 = scan3.nextInt();
			delete(id3);
			break;
		case 6:
			System.out.println("Enter ID");
			Scanner scan4 = new Scanner(System.in);
			int id4 = scan4.nextInt();
			generateReport(id4);
			break;
			}
		
		}while(choice!=6);
	}
}
